values = [1, 1, 1, 1, 1, 1, 1]


def abian():
    # VERSIÓN ABIÁN
    avg = sum(values) / len(values)
    for value in values:
        if value != avg:
            print('No son iguales')
            break
    else:
        print('Son iguales')


def diego():
    first_value = values[0]
    for value in values[1:]:
        if value != first_value:
            print('Son distintos')
            break
    else:
        print('Son iguales')


first_value = values[0]
if values.count(first_value) == len(values):
    print('Son iguales')
else:
    print('Son distintos')
