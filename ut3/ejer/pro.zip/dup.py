values = [0, 0, 1, 2, 3, 4, 4, 5, 6, 6, 6, 7, 8, 9, 4, 4]

prev = None
non_consecutive = []

for current in values:
    if current != prev:
        non_consecutive.append(current)
    prev = current

print(non_consecutive)
