values = [0, 0, 1, 2, 3, 4, 4, 5, 6, 6, 6, 7, 8, 9, 4, 4]

non_consecutive = [values[0]]

for i in range(1, len(values)):
    curr = values[i]
    prev = values[i - 1]
    if curr != prev:
        non_consecutive.append(curr)

print(non_consecutive)
