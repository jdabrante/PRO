matrix = [[4, 6, 1], [2, 9, 3], [1, 7, 7]]

size = len(matrix)
main_diagonal = [matrix[i][i] for i in range(size)]
sum_diagonal = sum(main_diagonal)
print(sum_diagonal)
