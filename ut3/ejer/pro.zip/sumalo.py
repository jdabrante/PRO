import sys

a = float(sys.argv[1])
b = float(sys.argv[2])

result = a + b
print(result)
