BASE = 2
SIZE = 10

# exponent_number = []
# for i in range(number + 1):
#    result = BASE**i
#    exponent_number.append(result)
#
# print(exponent_number)

exponent_number = [BASE**i for i in range(SIZE + 1)]
print(exponent_number)
