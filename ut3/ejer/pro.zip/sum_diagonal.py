matrix = [[4, 6, 1], [2, 9, 3], [1, 7, 7]]

size = len(matrix)
sum_values = 0
for i in range(size):
    sum_values += matrix[i][i]
print(sum_values)
